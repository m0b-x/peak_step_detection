class SensorConfig {
  final bool warmUpSensors;
  final int warmUpDurationMs;
  final int minStepGapMs;

  final bool useSystemDefaultInterval;
  final int pollingIntervalMs;
  final int userInterfaceUpdateIntervalMs;

  final int filterOrder;
  final double filterCutoffFreq;

  final double accThreshold;
  final double gyroThreshold;

  final double accelerometerScale;
  final double gyroScale;
  final double magScale;

  final double shortStep;
  final double mediumStep;
  final double longStep;
  final double bigStepThreshold;
  final double mediumStepThreshold;

  final int startVectorSize;
  final int endVectorSize;
  final int maxWindowSize;

  const SensorConfig({
    this.useSystemDefaultInterval = false,
    this.pollingIntervalMs = 100,
    this.userInterfaceUpdateIntervalMs = 100,
    this.minStepGapMs = 300,
    this.filterOrder = 3,
    this.filterCutoffFreq = 1.0,
    this.maxWindowSize = 15,
    this.accThreshold = 1.0,
    this.gyroThreshold = 1.0,
    this.accelerometerScale = 1.0,
    this.gyroScale = 1.0,
    this.magScale = 1.0,
    this.shortStep = 0.5,
    this.mediumStep = 1.0,
    this.longStep = 1.5,
    this.bigStepThreshold = 0.13,
    this.mediumStepThreshold = 0.1,
    this.warmUpSensors = true,
    this.warmUpDurationMs = 5000,
    this.startVectorSize = 3,
    this.endVectorSize = 2,
  });

  SensorConfig copyWith({
    // Sampling
    bool? useSystemDefaultInterval,
    int? pollingIntervalMs,
    int? userInterfaceUpdateIntervalMs,
    int? startVectorSize,
    int? endVectorSize,
    // Filter
    int? filterOrder,
    double? filterCutoffFreq,
    // Thresholds
    double? accThreshold,
    double? gyroThreshold,
    // Scaling
    double? accScale,
    double? gyroScale,
    double? magScale,
    // Step model
    double? shortStep,
    double? mediumStep,
    double? longStep,
    double? bigStepThreshold,
    double? mediumStepThreshold,
    // Warm-up
    bool? warmUpSensors,
    int? warmUpDurationMs,
    int? maxWindowSize,
    int? minStepGapMs,
  }) {
    return SensorConfig(
      useSystemDefaultInterval:
          useSystemDefaultInterval ?? this.useSystemDefaultInterval,
      pollingIntervalMs: pollingIntervalMs ?? this.pollingIntervalMs,
      userInterfaceUpdateIntervalMs:
          userInterfaceUpdateIntervalMs ?? this.userInterfaceUpdateIntervalMs,
      filterOrder: filterOrder ?? this.filterOrder,
      filterCutoffFreq: filterCutoffFreq ?? this.filterCutoffFreq,
      accThreshold: accThreshold ?? this.accThreshold,
      gyroThreshold: gyroThreshold ?? this.gyroThreshold,
      accelerometerScale: accScale ?? accelerometerScale,
      gyroScale: gyroScale ?? this.gyroScale,
      magScale: magScale ?? this.magScale,
      shortStep: shortStep ?? this.shortStep,
      mediumStep: mediumStep ?? this.mediumStep,
      longStep: longStep ?? this.longStep,
      bigStepThreshold: bigStepThreshold ?? this.bigStepThreshold,
      mediumStepThreshold: mediumStepThreshold ?? this.mediumStepThreshold,
      warmUpSensors: warmUpSensors ?? this.warmUpSensors,
      warmUpDurationMs: warmUpDurationMs ?? this.warmUpDurationMs,
      startVectorSize: startVectorSize ?? this.startVectorSize,
      endVectorSize: endVectorSize ?? this.endVectorSize,
      maxWindowSize: maxWindowSize ?? this.maxWindowSize,
      minStepGapMs: minStepGapMs ?? this.minStepGapMs,
    );
  }
}
